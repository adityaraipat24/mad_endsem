package com.example.sqllite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DBHelper DBHelper;
    EditText editname,editsurname,editmarks;
    Button btnADD;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DBHelper =new DBHelper(this);
        editname=(EditText) findViewById(R.id.editTextTextPersonName);
        editsurname=(EditText) findViewById(R.id.editTextTextPersonName2);
        editmarks=(EditText) findViewById(R.id.editTextTextPersonName3);
        btnADD=(Button) findViewById(R.id.button);
        AddData();

    }
    public void AddData(){
        btnADD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               boolean isinserted= DBHelper.insertData(editname.getText().toString(),editsurname.getText().toString(),editmarks.getText().toString());
               if(isinserted=true)
                   Toast.makeText(MainActivity.this,"DATA INSERTED",Toast.LENGTH_SHORT).show();
               else
                   Toast.makeText(MainActivity.this,"DATA NOT INSERTED",Toast.LENGTH_SHORT).show();

            }
        });
    }


}